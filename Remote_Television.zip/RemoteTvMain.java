package com.workspace.firstintproject;

public class RemoteTvMain {
    public static void main(String[] args) {
        RemoteTv arn = new RemoteTv();
        arn.setCompany("Samsung");
        arn.setModel("Crystal LED");
        arn.setInch(55);
        System.out.println("Company: "+arn.getCompany());
        System.out.println("Model: "+arn.getModel());
        System.out.println("Inches: "+arn.getInch());
        arn.powerOn();
        arn.changeChannel(3);
        arn.increaseVol();
        arn.increaseVol();
        arn.decreaseVol();
        arn.powerOff();


    }
}
