package com.workspace.firstintproject;
public class RemoteTv extends Television{
    public int volume;
    public void powerOn(){
        System.out.println("System On");
    }
    public void powerOff(){
        System.out.println("System Off");
    }
    public void changeChannel(int g){
        String a="ABP MAJHA";
        String b="AAJ TAK";
        String c="HISTORY TV 18";
        if (g==1){
            System.out.println(a);
        }
        else if (g==2) {
            System.out.println(b);
        }
        else if(g==3){
            System.out.println(c);
        }
        else{
            System.out.println("Invalid !! Enter a value between 1 to 3");
        }

    }
    public void increaseVol(){
        if(volume<10){
            volume++;
            System.out.println("Volume Increased: "+volume);
        }
        else{
            System.out.println("Maximum Volume Reached!!");
        }
    }
    public void decreaseVol(){
        if(volume>0){
            volume--;
            System.out.println("Volume Decreased: "+volume);
        }
        else{
            System.out.println("Minimum Volume Reached!!");
        }
    }

}
